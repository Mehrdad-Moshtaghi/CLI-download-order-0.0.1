# CLI for ordering and downloading PlanetScope ortho visual products

This is for ordering and downloading PlanetScope ortho visual products


## Installation

You can easily install the module using `pip`.
```
pip install CLI-download-order-0.0.1.zip
```

## Using the CLI command

```
$ download_order [-h] Sdate Edate AOI PLANET_API_KEY
```